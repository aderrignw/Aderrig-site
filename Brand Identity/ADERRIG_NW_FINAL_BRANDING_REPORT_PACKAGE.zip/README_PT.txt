ADERRIG NW — Pacote oficial (logo completo)

Arquivos principais:
- ADERRIG_NW_master.png (logo completo em alta resolução, fundo branco)
- ADERRIG_NW_master_transparent.png (logo completo com fundo transparente)

Para o site (navbar):
- logo_site_44h.png (altura 44px, use direto)
- logo_site_88h_retina.png (altura 88px, versão retina; exibir como 44px)

Uso recomendado:
- Para header, use a versão transparente e defina a altura no CSS/HTML.
- Evite esticar a imagem; mantenha proporção (height + width auto).
