ADERRIG NW — Official package (full logo)

Master files:
- ADERRIG_NW_master.png (full logo, high-res, white background)
- ADERRIG_NW_master_transparent.png (full logo, transparent background)

Website navbar:
- logo_site_44h.png (44px height)
- logo_site_88h_retina.png (retina 2x; display at 44px)

Recommendation:
- Use the transparent version and set height in CSS/HTML (width auto).
- Do not stretch; keep aspect ratio.
